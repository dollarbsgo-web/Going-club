export interface Wallet {
  name: string;
  rate: string;
  type: 'Exchange' | 'Wallet' | 'Payment' | 'Crypto';
  imageUrl: string;
  popular?: boolean;
}

export interface PaymentLog {
  id: string;
  method: string;
  amount: string;
  time: string;
  status: 'Completed' | 'Processing';
}

export interface Review {
  id: string;
  name: string;
  text: string;
  rating: number;
  time: string;
  color: string;
  tc: string;
}
