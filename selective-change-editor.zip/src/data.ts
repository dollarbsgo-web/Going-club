import { Wallet, PaymentLog, Review } from './types';

export const BANNERS = [
  "https://i.postimg.cc/02mdk1Cx/file-000000009f687209bcd1e25b1e62afed.png",
  "https://i.postimg.cc/TYmqdvJz/file-00000000cec87209ac2f1f4498528ffd.png",
  "https://i.postimg.cc/RVfQSxLY/file-000000006f6c7209a55d62f596635f15.png",
  "https://i.postimg.cc/13kJD3sf/file-00000000a0cc7208ab197454909c18da.png"
];

export const WALLETS: Wallet[] = [
  {
    name: "Binance USDT",
    rate: "121.50",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/MTKgSnxp/download-(9).png",
    popular: true
  },
  {
    name: "Bybit USD",
    rate: "122.00",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/ydY2HDBR/download.png",
    popular: true
  },
  {
    name: "OKX USDT",
    rate: "121.80",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/sfbzc9CP/download-(5).png",
    popular: true
  },
  {
    name: "KuCoin USDT",
    rate: "121.40",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/rmF7kDcD/download-(6).png"
  },
  {
    name: "Bitget USD",
    rate: "121.60",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/h4NnrbR1/download-(7).png"
  },
  {
    name: "RedotPay USD",
    rate: "120.50",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/pTX3Hmxh/download-(10).png"
  },
  {
    name: "Payoneer USD",
    rate: "121.00",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/dQx2NgLT/download-(1).png"
  },
  {
    name: "Wise USD",
    rate: "122.50",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/fL8zDJyX/file-0000000033c8720bbc3ca61fcb7e91b5.png"
  },
  {
    name: "AstroPay USD",
    rate: "123.00",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/RCD7p2NN/download-(3).jpg"
  },
  {
    name: "Bitcoin USD",
    rate: "120.80",
    type: "Crypto",
    imageUrl: "https://i.postimg.cc/gc1pDqbV/download-(2).png"
  },
  {
    name: "Tron TRC20",
    rate: "121.20",
    type: "Crypto",
    imageUrl: "https://i.postimg.cc/XNtW8c6w/download-(3).png",
    popular: true
  },
  {
    name: "Trust Wallet",
    rate: "121.70",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/BbJJTJKp/file-00000000c75871fa8478b5b6b01d00b4.png"
  },
  {
    name: "Quotex",
    rate: "121.90",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/G36RQJnG/download-(4).png",
    popular: true
  },
  {
    name: "Skrill USD",
    rate: "122.20",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/T24VNBpL/download-(1).jpg"
  },
  {
    name: "Neteller USD",
    rate: "121.85",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/05BYXhbr/download-(2).jpg"
  },
  {
    name: "AdvCash USD",
    rate: "120.90",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/tRM3v8Yn/download-(8).png"
  },
  {
    name: "PayPal USD",
    rate: "122.30",
    type: "Payment",
    imageUrl: "https://i.postimg.cc/85PxS7DL/download-(11).png"
  },
  {
    name: "Perfect Money",
    rate: "120.30",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/vBqkHGHc/perfectmoney-cryptocurrencies-icon-188320.png"
  },
  {
    name: "MetaMask Wallet",
    rate: "121.10",
    type: "Wallet",
    imageUrl: "https://i.postimg.cc/pTG4XPXh/download-(12).png"
  },
  {
    name: "Telegram Wallet",
    rate: "121.45",
    type: "Wallet",
    imageUrl: "https://cdn.simpleicons.org/telegram/26A5E4"
  },
  {
    name: "MEXC USD",
    rate: "121.55",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/Tw7FYTYK/download-(13).png"
  },
  {
    name: "Coinbase Exchange",
    rate: "122.10",
    type: "Exchange",
    imageUrl: "https://i.postimg.cc/k41zX7Xt/download-(4).jpg"
  }
];

export const INITIAL_PAYMENTS: PaymentLog[] = [
  { id: "p1", method: "bKash → Binance USDT", amount: "$50.00", time: "২ মিনিট আগে", status: "Completed" },
  { id: "p2", method: "Nagad → Bybit USD", amount: "$100.00", time: "৫ মিনিট আগে", status: "Completed" },
  { id: "p3", method: "Trust Wallet → bKash", amount: "$75.50", time: "৮ মিনিট আগে", status: "Completed" },
  { id: "p4", method: "Bank Transfer → Wise", amount: "$200.00", time: "১৫ মিনিট আগে", status: "Completed" },
  { id: "p5", method: "RedotPay → Nagad", amount: "$30.00", time: "২২ মিনিট আগে", status: "Completed" },
  { id: "p6", method: "bKash → KuCoin USDT", amount: "$500.00", time: "৩৫ মিনিট আগে", status: "Completed" },
  { id: "p7", method: "Quotex → Bank Transfer", amount: "$150.00", time: "৪৮ মিনিট আগে", status: "Completed" },
  { id: "p8", method: "Nagad → Tron TRC20", amount: "$25.00", time: "১ ঘণ্টা আগে", status: "Completed" }
];

export const GENERATED_PAYMENTS_POOL = [
  { method: "bKash → RedotPay USD", amount: "$35.00" },
  { method: "Nagad → Wise USD", amount: "$70.00" },
  { method: "Skrill USD → bKash", amount: "$110.00" },
  { method: "PayPal USD → Bank Transfer", amount: "$85.00" },
  { method: "Bybit USD → Nagad", amount: "$45.00" },
  { method: "Binance USDT → Bank Transfer", amount: "$120.00" },
  { method: "Bitcoin USD → bKash", amount: "$55.00" },
  { method: "Tron TRC20 → Nagad", amount: "$130.00" },
  { id: "pg1", method: "Neteller USD → bKash", amount: "$90.00" },
  { id: "pg2", method: "AdvCash USD → Nagad", amount: "$40.00" }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: "r1",
    name: "ইমরান খান",
    text: "অসাধারণ সার্ভিস! মাত্র ৩ মিনিটে ডলার পেয়ে গেলাম ওয়ালেটে।",
    rating: 5,
    time: "৮ ঘণ্টা আগে",
    color: "bg-blue-500/10",
    tc: "text-blue-400"
  },
  {
    id: "r2",
    name: "সুমাইয়া আক্তার",
    text: "এক্সচেঞ্জ রেট সবসময় ভালো পাওয়া যায়। অনেকদিন ধরে CoinSwap ব্যবহার করছি।",
    rating: 5,
    time: "১০ ঘণ্টা আগে",
    color: "bg-green-500/10",
    tc: "text-green-400"
  },
  {
    id: "r3",
    name: "রাকিব হাসান",
    text: "সাপোর্ট টিম অনেক হেল্পফুল এবং রেসপন্সিভ। প্রথমবার লেনদেন করলাম কোনো ভীতি ছাড়া।",
    rating: 5,
    time: "১৪ ঘণ্টা আগে",
    color: "bg-purple-500/10",
    tc: "text-purple-400"
  },
  {
    id: "r4",
    name: "ফাতেমা আক্তার",
    text: "বিকাশে টাকা পাঠিয়ে USDT নিলাম, সুপার ফাস্ট ডেলিভারি! অনেক ধন্যবাদ।",
    rating: 5,
    time: "১৮ ঘণ্টা আগে",
    color: "bg-amber-500/10",
    tc: "text-amber-400"
  },
  {
    id: "r5",
    name: "তানভীর ইসলাম",
    text: "টাকা উইথড্র দিয়েছিলাম Quotex থেকে, বিকাশ পেমেন্ট একদম সময়ে পেয়েছি।",
    rating: 5,
    time: "২০ ঘণ্টা আগে",
    color: "bg-cyan-500/10",
    tc: "text-cyan-400"
  },
  {
    id: "r6",
    name: "নুসরাত জাহান",
    text: "ডলার সেল করলাম এবং বিকাশ নাম্বারে টাকা সাথে সাথে পেলাম। অত্যন্ত বিশ্বস্ত।",
    rating: 5,
    time: "১ দিন আগে",
    color: "bg-rose-500/10",
    tc: "text-rose-400"
  }
];

export const GENERATED_REVIEWS_POOL = [
  { name: "মাহমুদুল হক", text: "সবাইকে রিকমেন্ড করবো, খুব কম সময়ে নিরাপদে ট্রানজেকশন হয়েছে।" },
  { name: "আরিফ হোসেন", text: "নগদ থেকে খুব চটজলদি বাই সম্পন্ন করেছি। বাই রেট সেরা!" },
  { name: "শরিফুল ইসলাম", text: "রেডটপে ডলার লাগবে বলতেই ইনস্ট্যান্ট বাই ও কনফার্মেশন পেলাম।" },
  { name: "রুমানা শেখ", text: "Bybit USD এক্সচেঞ্জ রেট সবচেয়ে সেরা পেয়েছি CoinSwap-এ।" },
  { name: "তাহসিনুল কবীর", text: "হোয়াটসঅ্যাপ সাপোর্ট অনেক চমৎকার, সরাসরি কথা বলে সন্তুষ্ট।" },
  { name: "সাদিয়া মিলি", text: "Wise থেকে বিকাশে উইথড্র করার সেরা মাধ্যম এটি।" }
];
