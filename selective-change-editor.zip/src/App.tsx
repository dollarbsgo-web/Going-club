import React, { useState, useEffect, useRef } from 'react';
import { 
  Check, 
  Copy, 
  Download, 
  Menu, 
  X, 
  ShieldCheck, 
  Zap, 
  Smile, 
  TrendingUp, 
  Headphones, 
  UploadCloud, 
  Trash2, 
  ChevronDown, 
  CheckCircle, 
  AlertCircle,
  MessageSquare,
  Phone,
  Star,
  ExternalLink,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Wallet, PaymentLog, Review } from './types';
import { 
  WALLETS, 
  BANNERS, 
  INITIAL_PAYMENTS, 
  GENERATED_PAYMENTS_POOL, 
  INITIAL_REVIEWS, 
  GENERATED_REVIEWS_POOL 
} from './data';

const WHATSAPP_NUMBER = '8801874893935';
const CONTACT_PHONE = '01829-052846';
const SYSTEM_USDT_RATE = 121.79;
const IMGBB_KEY = '566ccd1975efcfa62193fa6ba004c6b8';

export default function App() {
  // Navigation / Custom state
  const [activeTab, setActiveTab] = useState<'buy' | 'sell'>('buy');
  const [walletFilter, setWalletFilter] = useState<string>('all');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [currentBannerIdx, setCurrentBannerIdx] = useState<number>(0);
  
  // Real-time animated ticker states
  const [payments, setPayments] = useState<PaymentLog[]>(INITIAL_PAYMENTS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  
  // Form input states
  // -- Buy State
  const [buyUid, setBuyUid] = useState('');
  const [buyAmount, setBuyAmount] = useState('');
  const [buyPaymentMethod, setBuyPaymentMethod] = useState<'bkash' | 'nagad' | 'bank' | null>(null);
  const [buyTxnId, setBuyTxnId] = useState('');
  const [buyPayerPhone, setBuyPayerPhone] = useState('');
  const [buyFile, setBuyFile] = useState<File | null>(null);
  const [buyPreview, setBuyPreview] = useState<string>('');
  
  // -- Sell State
  const [sellUid, setSellUid] = useState('');
  const [sellAmount, setSellAmount] = useState('');
  const [sellPaymentMethod, setSellPaymentMethod] = useState<'bkash' | 'nagad' | 'bank' | null>(null);
  const [sellReceiverPhone, setSellReceiverPhone] = useState('');
  const [sellTxnId, setSellTxnId] = useState('');
  const [sellFile, setSellFile] = useState<File | null>(null);
  const [sellPreview, setSellPreview] = useState<string>('');

  // Actions loading states
  const [submittingBuy, setSubmittingBuy] = useState(false);
  const [submittingSell, setSubmittingSell] = useState(false);

  // Toast States
  const [toasts, setToasts] = useState<{ id: number; message: string; type: 'success' | 'error' }[]>([]);

  const addToast = (message: string, type: 'success' | 'error' = 'success') => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  // Automated Banner Carousel
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentBannerIdx(prev => (prev + 1) % BANNERS.length);
    }, 4500);
    return () => clearInterval(slideInterval);
  }, []);

  // Live updates simulator: Adds realistic new payments & reviews in real-time
  useEffect(() => {
    const paymentTimer = setInterval(() => {
      const randomItem = GENERATED_PAYMENTS_POOL[Math.floor(Math.random() * GENERATED_PAYMENTS_POOL.length)];
      const ratesList = [121.50, 121.80, 122.00, 121.20];
      const randomRate = ratesList[Math.floor(Math.random() * ratesList.length)];
      const minAgo = Math.floor(Math.random() * 4) + 1;
      
      const newLog: PaymentLog = {
        id: `pg-${Date.now()}`,
        method: randomItem.method,
        amount: randomItem.amount,
        time: `${minAgo} মিনিট আগে`,
        status: 'Completed'
      };
      
      setPayments(prev => [newLog, ...prev.slice(0, 7)]);
    }, 8000);

    const reviewTimer = setInterval(() => {
      const randomReviewTemplate = GENERATED_REVIEWS_POOL[Math.floor(Math.random() * GENERATED_REVIEWS_POOL.length)];
      const colorOptions = [
        { c: 'bg-blue-500/10', tc: 'text-blue-400' },
        { c: 'bg-green-500/10', tc: 'text-green-400' },
        { c: 'bg-purple-500/10', tc: 'text-purple-400' },
        { c: 'bg-amber-500/10', tc: 'text-amber-400' },
        { c: 'bg-cyan-500/10', tc: 'text-cyan-400' }
      ];
      const randomColors = colorOptions[Math.floor(Math.random() * colorOptions.length)];

      const newReview: Review = {
        id: `rev-${Date.now()}`,
        name: randomReviewTemplate.name,
        text: randomReviewTemplate.text,
        rating: 5,
        time: 'এখনই',
        color: randomColors.c,
        tc: randomColors.tc
      };

      setReviews(prev => [newReview, ...prev.slice(0, 5)]);
    }, 14000);

    return () => {
      clearInterval(paymentTimer);
      clearInterval(reviewTimer);
    };
  }, []);

  // Utility actions
  const copyText = (text: string, label: string) => {
    const rawNumber = text.replace(/-/g, '').trim();
    navigator.clipboard.writeText(rawNumber).then(() => {
      addToast(`${label} নম্বর কপি হয়েছে!`, 'success');
    }).catch(() => {
      // Fallback
      const input = document.createElement('textarea');
      input.value = rawNumber;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      addToast(`${label} নম্বর কপি হয়েছে!`, 'success');
    });
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToForm = (tab: 'buy' | 'sell') => {
    setActiveTab(tab);
    scrollToSection('form-section');
  };

  // Image upload and hosting handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'buy' | 'sell') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      addToast('অনুগ্রহ করে শুধুমাত্র JPG, PNG অথবা WebP ইমেজ আপলোড দিন', 'error');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      addToast('ইমেজের সাইজ সর্বোচ্চ ৫MB হতে পারবে', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (type === 'buy') {
        setBuyFile(file);
        setBuyPreview(event.target?.result as string);
      } else {
        setSellFile(file);
        setSellPreview(event.target?.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const triggerUploadToImgBB = async (file: File): Promise<string> => {
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = (e) => {
          const raw = e.target?.result as string;
          resolve(raw.split(',')[1]);
        };
        reader.readAsDataURL(file);
      });
      const base64Data = await base64Promise;

      const fd = new FormData();
      fd.append('key', IMGBB_KEY);
      fd.append('image', base64Data);

      const response = await fetch('https://api.imgbb.com/1/upload', {
        method: 'POST',
        body: fd
      });
      const result = await response.json();
      if (result.success) {
        return result.data.url;
      }
      return '';
    } catch (err) {
      console.error('ImgBB implementation failback:', err);
      return '';
    }
  };

  const removeFile = (type: 'buy' | 'sell') => {
    if (type === 'buy') {
      setBuyFile(null);
      setBuyPreview('');
    } else {
      setSellFile(null);
      setSellPreview('');
    }
  };

  // Handle Order Forms
  const handleBuySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyUid.trim()) {
      addToast('আপনার Binance / Bybit UID দিন!', 'error');
      return;
    }
    const parsedAmount = parseFloat(buyAmount);
    if (!buyAmount || isNaN(parsedAmount) || parsedAmount <= 0) {
      addToast('সঠিক USDT পরিমাণ দিন!', 'error');
      return;
    }
    if (!buyPaymentMethod) {
      addToast('পেমেন্ট মাধ্যম সিলেক্ট করুন!', 'error');
      return;
    }
    if (!buyTxnId.trim()) {
      addToast('পেমেন্ট ট্রানজেকশন ID দিন!', 'error');
      return;
    }
    if (!buyPayerPhone.trim()) {
      addToast('পেমেন্টকারী মোবাইল নাম্বারটি দিন!', 'error');
      return;
    }

    setSubmittingBuy(true);
    let uploadedUrl = '';
    
    if (buyFile) {
      addToast('স্ক্রিনশট আপলোড হচ্ছে, দয়া করে অপেক্ষা করুন...', 'success');
      uploadedUrl = await triggerUploadToImgBB(buyFile);
    }

    try {
      const calculatedCost = (parsedAmount * SYSTEM_USDT_RATE).toFixed(2);
      const paymentLabel = buyPaymentMethod === 'bkash' ? 'bKash' : buyPaymentMethod === 'nagad' ? 'Nagad' : 'Bank Transfer';
      
      let message = `🟢 *CoinSwap BUY Request*\n\n`;
      message += `📋 *ধরণ:* USDT Buy\n`;
      message += `🆔 *কাস্টমার UID:* ${buyUid.trim()}\n`;
      message += `💰 * পরিমাণ:* ${parsedAmount.toFixed(2)} USDT\n`;
      message += `💵 *রেট:* ৳${SYSTEM_USDT_RATE}\n`;
      message += `💳 * পেমেন্ট মাধ্যম:* ${paymentLabel}\n`;
      message += `🔢 *পেমেন্ট নম্বর:* ${buyPayerPhone.trim()}\n`;
      message += `📝 *ট্রানজেকশন ID:* ${buyTxnId.trim()}\n`;
      message += `💰 *সর্বমোট পেমেন্ট:* ৳${calculatedCost} BDT\n`;
      
      if (uploadedUrl) {
        message += `\n🖼️ *স্ক্রিনশট লিংক:* ${uploadedUrl}`;
      } else if (buyPreview) {
        message += `\n📸 স্ক্রিনশট ইমেজ সংযুক্ত করা আছে, সরাসরি নিচে হোয়াটসঅ্যাপ চ্যাটে প্রদান করছি।`;
      }

      const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
      
      addToast('হোয়াটসঅ্যাপে রিডাইরেক্ট করা হচ্ছে...', 'success');
      setTimeout(() => {
        window.open(whatsappUrl, '_blank', 'noreferrer');
        setSubmittingBuy(false);
      }, 800);
    } catch (err) {
      setSubmittingBuy(false);
      addToast('অর্ডার সাবমিট করতে সমস্যা হয়েছে। হোয়াটসঅ্যাপে সরাসরি মেসেজ করুন।', 'error');
    }
  };

  const handleSellSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sellUid.trim()) {
      addToast('আপনার Binance / Bybit UID দিন!', 'error');
      return;
    }
    const parsedAmount = parseFloat(sellAmount);
    if (!sellAmount || isNaN(parsedAmount) || parsedAmount <= 0) {
      addToast('সঠিক বিক্রয় USDT পরিমাণ দিন!', 'error');
      return;
    }
    if (!sellPaymentMethod) {
      addToast('টাকা কোন মাধ্যমে নিতে চান তা সিলেক্ট করুন!', 'error');
      return;
    }
    if ((sellPaymentMethod === 'bkash' || sellPaymentMethod === 'nagad') && !sellReceiverPhone.trim()) {
      addToast('আপনার bKash/Nagad নাম্বার দিন!', 'error');
      return;
    }
    if (!sellTxnId.trim()) {
      addToast('USDT পাঠানোর পর পাওয়া ক্রিপ্টো TxID / Hash দিন!', 'error');
      return;
    }

    setSubmittingSell(true);
    let uploadedUrl = '';
    
    if (sellFile) {
      addToast('প্রমাণ স্ক্রিনশট আপলোড হচ্ছে...', 'success');
      uploadedUrl = await triggerUploadToImgBB(sellFile);
    }

    try {
      const calculatedPayout = (parsedAmount * SYSTEM_USDT_RATE).toFixed(2);
      const paymentLabel = sellPaymentMethod === 'bkash' ? 'bKash' : sellPaymentMethod === 'nagad' ? 'Nagad' : 'Bank Transfer';
      
      let message = `🔴 *CoinSwap SELL Request*\n\n`;
      message += `📋 *ধরণ:* USDT Sell\n`;
      message += `🆔 *কাস্টমার UID:* ${sellUid.trim()}\n`;
      message += `💰 *বিক্রয় পরিমাণ:* ${parsedAmount.toFixed(2)} USDT\n`;
      message += `💵 *রেট:* ৳${SYSTEM_USDT_RATE}\n`;
      message += `💳 *টাকা পাওয়ার মাধ্যম:* ${paymentLabel}\n`;
      
      if (sellPaymentMethod !== 'bank') {
        message += `📱 *রিসিভার নাম্বার:* ${sellReceiverPhone.trim()}\n`;
      } else {
        message += `🏦 *ব্যাংক ক্যাশআউট:* ব্যাংক ডিটেইলস চ্যাটে দিচ্ছি।\n`;
      }
      
      message += `🔢 *ক্রিপ্টো ট্রানজেকশন ID/Hash:* ${sellTxnId.trim()}\n`;
      message += `৳ *আপনি পাবেন (সর্বমোট):* ৳${calculatedPayout} BDT\n`;

      if (uploadedUrl) {
        message += `\n🖼️ *স্ক্রিনশট লিংক:* ${uploadedUrl}`;
      } else if (sellPreview) {
        message += `\n📸 স্ক্রিনশট ইমেজ সংযুক্ত করা আছে, সরাসরি হোয়াটসঅ্যাপে প্রদান করছি।`;
      }

      const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
      
      addToast('হোয়াটসঅ্যাপে রিডাইরেক্ট করা হচ্ছে...', 'success');
      setTimeout(() => {
        window.open(whatsappUrl, '_blank', 'noreferrer');
        setSubmittingSell(false);
      }, 800);
    } catch (err) {
      setSubmittingSell(false);
      addToast('অর্ডার প্রসেস ব্যর্থ হয়েছে, দয়া করে হোয়াটসঅ্যাপে সরাসরি যোগাযোগ করুন।', 'error');
    }
  };

  // Drag and Drop helpers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Filter computation for wallets section
  const filteredWallets = walletFilter === 'all' 
    ? WALLETS 
    : WALLETS.filter(w => w.type === walletFilter);

  return (
    <div className="min-h-screen bg-[#0B0F19] text-white selection:bg-blue-600 selection:text-white font-sans overflow-x-hidden antialiased">
      
      {/* Dynamic Toast System */}
      <div className="fixed top-24 right-4 z-[999] flex flex-col gap-3 max-w-sm w-full px-4">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 15, scale: 0.95 }}
              transition={{ duration: 0.3, cubicBezier: [0.16, 1, 0.3, 1] }}
              className={`flex items-start gap-3 p-4 rounded-xl shadow-2xl backdrop-blur-xl border ${
                toast.type === 'success' 
                  ? 'bg-green-950/90 border-green-500/30 text-green-100' 
                  : 'bg-red-950/90 border-red-500/30 text-red-100'
              }`}
            >
              <div className="mt-0.5">
                {toast.type === 'success' ? (
                  <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                )}
              </div>
              <div className="flex-1 text-sm font-medium leading-relaxed">
                {toast.message}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Modern Navigation Header */}
      <nav className="bg-[#0B0F19]/80 backdrop-blur-xl sticky top-0 z-50 border-b border-gray-800/50 transition-all duration-300">
        <div className="flex justify-between items-center w-full px-4 md:px-12 max-w-[1240px] mx-auto h-16">
          <div className="flex items-center gap-3">
            <img 
              src="https://i.postimg.cc/cCGfLs83/IMG-20260524-WA0001.jpg" 
              alt="CoinSwap" 
              className="h-10 w-10 rounded-full object-cover ring-2 ring-blue-500/30"
              referrerPolicy="no-referrer"
            />
            <span className="font-display text-xl font-extrabold text-[#FFFFFF] tracking-tight">
              Coin<span className="text-[#3B82F6]">Swap</span>
            </span>
          </div>

          {/* Desktop Nav Items */}
          <div className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => { setActiveTab('buy'); scrollToSection('form-section'); }}
              className={`font-semibold text-sm transition-all pb-1 border-b-2 hover:-translate-y-[1px] ${
                activeTab === 'buy' ? 'text-blue-500 border-blue-500' : 'text-gray-400 border-transparent hover:text-white'
              }`}
            >
              বাই ক্রিপ্টো
            </button>
            <button 
              onClick={() => { setActiveTab('sell'); scrollToSection('form-section'); }}
              className={`font-semibold text-sm transition-all pb-1 border-b-2 hover:-translate-y-[1px] ${
                activeTab === 'sell' ? 'text-blue-500 border-blue-500' : 'text-gray-400 border-transparent hover:text-white'
              }`}
            >
              সেল ক্রিপ্টো
            </button>
            <button 
              onClick={() => scrollToSection('wallet-rates')}
              className="text-gray-400 font-medium text-sm hover:text-white transition-all hover:-translate-y-[1px]"
            >
              ওয়ালেট রেট
            </button>
            <button 
              onClick={() => scrollToSection('live-ticker')}
              className="text-gray-400 font-medium text-sm hover:text-white transition-all hover:-translate-y-[1px]"
            >
              লেনদেনের প্রমাণ
            </button>
            <button 
              onClick={() => scrollToSection('faq')}
              className="text-gray-400 font-medium text-sm hover:text-white transition-all hover:-translate-y-[1px]"
            >
              FAQ
            </button>
          </div>

          <div className="flex items-center gap-3">
            <a 
              href="https://play.google.com/store/apps/details?id=dev.vlab.com.local_coin" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold bg-gradient-to-r from-blue-500 to-blue-600 transition-all hover:shadow-lg hover:shadow-blue-500/20 active:scale-95 text-white"
            >
              <Download className="w-4 h-4" /> অ্যাপ ডাউনলোড
            </a>
            <button 
              onClick={() => setMobileMenuOpen(prev => !prev)}
              className="p-2 rounded-full hover:bg-gray-800/60 text-gray-300 md:hidden transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-gray-800 bg-[#121826]/95 backdrop-blur-xl overflow-hidden"
            >
              <div className="px-4 py-6 space-y-4">
                <button 
                  onClick={() => { setActiveTab('buy'); scrollToSection('form-section'); }}
                  className="block w-full text-left py-2.5 px-4 rounded-xl text-gray-300 font-medium hover:bg-gray-800/50 hover:text-blue-400 transition-colors"
                >
                  🟢 বাই ক্রিপ্টো (Buy USDT)
                </button>
                <button 
                  onClick={() => { setActiveTab('sell'); scrollToSection('form-section'); }}
                  className="block w-full text-left py-2.5 px-4 rounded-xl text-gray-300 font-medium hover:bg-gray-800/50 hover:text-blue-400 transition-colors"
                >
                  🔴 সেল ক্রিপ্টো (Sell USDT)
                </button>
                <button 
                  onClick={() => scrollToSection('wallet-rates')}
                  className="block w-full text-left py-2.5 px-4 rounded-xl text-gray-300 font-medium hover:bg-gray-800/50 hover:text-blue-400 transition-colors"
                >
                  👛 ওয়ান ট্যাপ ওয়ালেট রেট
                </button>
                <button 
                  onClick={() => scrollToSection('live-ticker')}
                  className="block w-full text-left py-2.5 px-4 rounded-xl text-gray-300 font-medium hover:bg-gray-800/50 hover:text-blue-400 transition-colors"
                >
                  📜 রিসেন্ট ট্রানজেকশন গ্যালারি
                </button>
                <button 
                  onClick={() => scrollToSection('faq')}
                  className="block w-full text-left py-2.5 px-4 rounded-xl text-gray-300 font-medium hover:bg-gray-800/50 hover:text-blue-400 transition-colors"
                >
                  💬 সাধারণ জিজ্ঞাসা (FAQ)
                </button>
                <div className="pt-2 px-4">
                  <a 
                    href="https://play.google.com/store/apps/details?id=dev.vlab.com.local_coin" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-blue-600 text-white font-bold text-sm text-center shadow-lg hover:bg-blue-700"
                  >
                    <Download className="w-4 h-4" /> গেট অফিশিয়াল অ্যাপ
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Dynamic Premium Banner Slider */}
      <section className="relative w-full overflow-hidden bg-gradient-to-b from-[#0b0f19] to-[#121826]">
        <div className="relative w-full aspect-[21/9] xs:aspect-[16/7] md:aspect-[24/10] max-h-[520px]">
          {BANNERS.map((bannerUrl, idx) => (
            <div 
              key={bannerUrl}
              className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
                idx === currentBannerIdx ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              <img 
                src={bannerUrl} 
                alt={`CoinSwap Banner ${idx + 1}`} 
                className="w-full h-full object-cover"
                loading={idx === 0 ? "eager" : "lazy"}
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F19] via-transparent to-transparent pointer-events-none" />
            </div>
          ))}
        </div>

        {/* Carousel Slide Indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2.5 z-20">
          {BANNERS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentBannerIdx(idx)}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                idx === currentBannerIdx ? 'bg-blue-500 w-8' : 'bg-gray-600 hover:bg-gray-500 w-2.5'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </section>

      {/* USDT Key Pricing Stats Overview */}
      <section className="py-8 md:py-12 bg-gradient-to-b from-[#121826] to-[#0B0F19]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          <div className="glass-card rounded-2xl p-6 md:p-8 max-w-3xl mx-auto text-center border-blue-500/10 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <DollarSign className="w-48 h-48 text-blue-500" />
            </div>
            
            <div className="flex items-center justify-center gap-2 mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" />
              <span className="font-mono text-xs text-blue-400 tracking-widest font-semibold uppercase">LIVE COINSWAP RATE</span>
            </div>

            <div className="flex items-baseline justify-center gap-2 mb-2">
              <span className="text-4xl md:text-5xl lg:text-6xl text-white font-black tracking-tight">৳১২১.৭৯</span>
              <span className="text-gray-400 text-sm font-semibold">/ USDT</span>
            </div>
            
            <p className="text-sm gap-1.5 inline-flex items-center text-green-400 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20 font-medium mb-6">
              মার্কেটের সেরা এক্সচেঞ্জ রেট নিশ্চিত করা হয়েছে
            </p>

            <div className="flex flex-col xs:flex-row gap-3.5 max-w-md mx-auto mb-8">
              <button 
                onClick={() => scrollToForm('buy')}
                className="flex-1 py-3.5 rounded-xl text-sm font-bold bg-blue-600 transition-all hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/25 text-white active:scale-95"
              >
                ডলার কিনুন (Buy USDT)
              </button>
              <button 
                onClick={() => scrollToForm('sell')}
                className="flex-1 py-3.5 rounded-xl text-sm font-bold bg-gray-800/80 border border-gray-700 hover:bg-gray-700 text-gray-200 transition-all active:scale-95"
              >
                ডলার বিক্রয় (Sell USDT)
              </button>
            </div>

            {/* Quick stats counter blocks */}
            <div className="grid grid-cols-3 gap-3 pt-6 border-t border-gray-800/60 max-w-xl mx-auto">
              <div className="bg-[#0B0F19]/60 rounded-xl p-3 border border-gray-800/40">
                <div className="font-extrabold text-[#3B82F6] text-lg sm:text-2xl leading-none mb-1">১০K+</div>
                <div className="text-gray-400 text-[11px] sm:text-xs">সন্তুষ্ট গ্রাহক</div>
              </div>
              <div className="bg-[#0B0F19]/60 rounded-xl p-3 border border-gray-800/40">
                <div className="font-extrabold text-[#3B82F6] text-lg sm:text-2xl leading-none mb-1">$১M+</div>
                <div className="text-gray-400 text-[11px] sm:text-xs">ট্রেড ভলিউম</div>
              </div>
              <div className="bg-[#0B0F19]/60 rounded-xl p-3 border border-gray-800/40">
                <div className="font-extrabold text-[#3B82F6] text-lg sm:text-2xl leading-none mb-1 font-display">৪.৮★</div>
                <div className="text-gray-400 text-[11px] sm:text-xs">প্লেস্টোর রেটিং</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== WALLET RATES SHOWCASE — 22 WALLETS WITH ACCURATE ORIGINAL LOGOS ========== */}
      <section id="wallet-rates" className="py-16 md:py-24 bg-[#121826]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          
          <div className="text-center mb-10 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight mb-3">
              ওয়ালেট অনুযায়ী এক্সচেঞ্জ রেট
            </h2>
            <p className="text-gray-400 text-sm md:text-base leading-relaxed">
              নিচে আমাদের সর্বশেষ ২২টি আন্তর্জাতিক গেটওয়ে ও ক্রিপ্টো নেটওয়ার্কের রিয়েল-টাইম রেট দেওয়া হলো। ওয়ান ক্লিকে যেকোনো কারেন্সি বেছে নিয়ে লেনদেন শুরু করতে পারেন।
            </p>
          </div>

          {/* Counts & Filter category bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-5 mb-8 bg-[#0B0F19]/60 border border-gray-800/80 p-4 rounded-2xl">
            <div className="flex items-center gap-3">
              <span className="text-gray-400 text-sm font-medium">সাপোর্টেড ওয়ালেট:</span>
              <span className="text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
                {filteredWallets.length}
              </span>
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shrink-0" />
              <span className="text-xs text-green-400 font-bold bg-green-500/10 px-2 py-0.5 rounded border border-green-500/20 uppercase font-mono">LIVE</span>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-1.5">
              {['all', 'Exchange', 'Wallet', 'Payment', 'Crypto'].map((filterVal) => {
                const labelMap: Record<string, string> = {
                  all: 'সব দেখুন',
                  Exchange: 'Exchange',
                  Wallet: 'Wallet',
                  Payment: 'Payment',
                  Crypto: 'Crypto'
                };
                return (
                  <button
                    key={filterVal}
                    onClick={() => setWalletFilter(filterVal)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      walletFilter === filterVal
                        ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                        : 'bg-transparent border-gray-800 text-gray-400 hover:border-gray-700 hover:text-white'
                    }`}
                  >
                    {labelMap[filterVal]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Responsive Bento-styled 22 Wallets Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5">
            <AnimatePresence mode="popLayout">
              {filteredWallets.map((wallet) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  key={wallet.name}
                  onClick={() => scrollToForm('buy')}
                  className="bg-[#0B0F19]/45 hover:bg-[#0B0F19] rounded-2xl border border-gray-800/80 hover:border-blue-500/30 p-4 text-center cursor-pointer relative group transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-black/45"
                >
                  {wallet.popular && (
                    <span className="absolute -top-1.5 -right-1 bg-amber-500 text-black font-black text-[9px] px-2 py-0.5 rounded-full shadow-lg border border-[#0B0F19]">
                      HOT
                    </span>
                  )}

                  <div className="w-14 h-14 mx-auto mb-3.5 rounded-xl bg-gray-900/40 group-hover:scale-105 transition-transform duration-300 flex items-center justify-center p-1 border border-gray-800/40 relative overflow-hidden">
                    <img 
                      src={wallet.imageUrl} 
                      alt={wallet.name} 
                      className="w-12 h-12 rounded-lg object-contain"
                      loading="lazy"
                      onError={(e) => {
                        // Fallback placeholder
                        (e.currentTarget as HTMLImageElement).src = `https://cdn.simpleicons.org/cryptocurrency/ffffff`;
                      }}
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <p className="font-semibold text-xs text-white leading-tight mb-1 truncate. group-hover:text-blue-400 transition-colors" title={wallet.name}>
                    {wallet.name}
                  </p>
                  
                  <p className="font-black font-mono text-base text-blue-500 leading-none mb-2.5">
                    ৳{wallet.rate}
                  </p>

                  <div className="flex flex-col items-center gap-1">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-gray-800/80 text-gray-400 border border-gray-700/50">
                      {wallet.type}
                    </span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          
        </div>
      </section>

      {/* ========== CORE TRANSACTION FORM SECTION ========== */}
      <section id="form-section" className="py-16 md:py-24 bg-[#0B0F19] relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.04),transparent_50%)] pointer-events-none" />
        
        <div className="max-w-[700px] mx-auto px-4 relative z-10">
          
          <div className="bg-[#121826] rounded-3xl border border-gray-800 shadow-2xl relative overflow-hidden">
            
            {/* Form Top Section */}
            <div className="p-6 md:p-8 text-center border-b border-gray-800/60 bg-gradient-to-r from-gray-900/50 to-gray-800/40">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[11px] font-bold text-blue-400 uppercase tracking-widest font-mono">লাইভ ট্রানজেকশন পোর্টাল</span>
              </div>
              <div className="flex items-baseline justify-center gap-1 mb-6">
                <span className="text-3xl md:text-4xl font-extrabold text-white">৳১২১.৭৯</span>
                <span className="text-gray-400 text-xs font-semibold">/ USDT</span>
              </div>

              {/* Slider Buy-Sell switcher links */}
              <div className="grid grid-cols-2 bg-black/40 border border-gray-800 p-1.5 rounded-xl max-w-sm mx-auto">
                <button
                  onClick={() => setActiveTab('buy')}
                  className={`py-2.5 px-4 rounded-lg font-bold text-xs sm:text-sm transition-all ${
                    activeTab === 'buy'
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/45'
                  }`}
                >
                  🟢 Buy USDT (কিনুন)
                </button>
                <button
                  onClick={() => setActiveTab('sell')}
                  className={`py-2.5 px-4 rounded-lg font-bold text-xs sm:text-sm transition-all ${
                    activeTab === 'sell'
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/45'
                  }`}
                >
                  🔴 Sell USDT (বিক্রি)
                </button>
              </div>
            </div>

            {/* TAB-1: BUY CRYTPO FORM */}
            <AnimatePresence mode="wait">
              {activeTab === 'buy' ? (
                <motion.form
                  key="buy-form"
                  initial={{ opacity: 0, x: -15 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 15 }}
                  transition={{ duration: 0.25 }}
                  onSubmit={handleBuySubmit}
                  className="p-6 md:p-8 space-y-6"
                >
                  {/* Dynamic Pricing feedback card */}
                  <div className="bg-[#0b0f19]/70 rounded-2xl p-4 border border-gray-800/80 space-y-2.5">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                      <span>কারেন্ট কনভার্সন রেট:</span>
                      <span className="font-bold font-mono text-blue-400">৳১২১.৭৯ BDT</span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-gray-400">
                      <span>USDT ক্রয় পরিমাণ:</span>
                      <span className="font-bold text-white">
                        {buyAmount ? `${parseFloat(buyAmount).toFixed(2)} USDT` : '0.00 USDT'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-2.5 mt-1.5 border-t border-gray-800/50">
                      <span className="text-sm font-semibold text-gray-300">আপনাকে সর্বমোট পাঠাতে হবে:</span>
                      <span className="text-lg font-black text-blue-400 font-mono">
                        ৳{buyAmount ? (parseFloat(buyAmount) * SYSTEM_USDT_RATE).toLocaleString('bn-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '০.০০'} BDT
                      </span>
                    </div>
                  </div>

                  {/* UID Input form element */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                      আপনার Binance / Bybit-এর UID <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={buyUid}
                      onChange={(e) => setBuyUid(e.target.value)}
                      placeholder="আপনার ৯ বা ১০ ডিজিটের UID নম্বরটি লিখুন"
                      className="w-full h-12 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-sm text-white placeholder-gray-500"
                    />
                  </div>

                  {/* Quantity input with fast presets */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                      কত ডলার কিনতে চান? (USDT) <span className="text-red-500">*</span>
                    </label>
                    <div className="relative mb-3">
                      <input
                        type="number"
                        min="1"
                        step="0.01"
                        required
                        value={buyAmount}
                        onChange={(e) => setBuyAmount(e.target.value)}
                        placeholder="ডলারের পরিমান লিখুন"
                        className="w-full h-12 px-4 pr-16 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-sm font-semibold text-white placeholder-gray-500"
                      />
                      <div className="absolute right-3.5 top-2.5 bottom-2.5 px-3 bg-gray-800 rounded-lg text-xs font-bold text-blue-400 flex items-center border border-gray-700">
                        USDT
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {[10, 25, 50, 100, 200, 500].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setBuyAmount(preset.toString())}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                            buyAmount === preset.toString()
                              ? 'bg-blue-600 border-blue-500 text-white'
                              : 'bg-[#0B0F19]/40 border-gray-800 text-gray-400 hover:text-white'
                          }`}
                        >
                          ${preset}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Choose Payment system */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-3 uppercase tracking-wider">
                      পেমেন্ট মেথড সিলেক্ট করুন <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-3 gap-2.5">
                      {/* bKash card logic */}
                      <div 
                        onClick={() => setBuyPaymentMethod('bkash')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          buyPaymentMethod === 'bkash' ? 'border-pink-500 bg-pink-500/5 shadow-md shadow-pink-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-pink-500/10">
                          <span className="font-black text-xs text-pink-500">bKash</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">বিকাশ</span>
                      </div>
                      
                      {/* Nagad Card logic */}
                      <div 
                        onClick={() => setBuyPaymentMethod('nagad')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          buyPaymentMethod === 'nagad' ? 'border-orange-500 bg-orange-500/5 shadow-md shadow-orange-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-orange-500/10">
                          <span className="font-black text-xs text-orange-500">নগদ</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">Nagad</span>
                      </div>

                      {/* Bank card logic */}
                      <div 
                        onClick={() => setBuyPaymentMethod('bank')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          buyPaymentMethod === 'bank' ? 'border-blue-500 bg-blue-500/5 shadow-md shadow-blue-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-blue-500/10">
                          <span className="font-black text-xs text-blue-500">Bank</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">ব্যাংক ট্রান্সফার</span>
                      </div>
                    </div>

                    {/* bKash/Nagad Specific Display info */}
                    {buyPaymentMethod && buyPaymentMethod !== 'bank' && (
                      <motion.div 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-3.5 bg-gray-900 border border-gray-800 p-4 rounded-xl flex items-center justify-between"
                      >
                        <div>
                          <p className="text-[10px] uppercase font-bold text-gray-400 tracking-wider mb-2">
                            আমাদের {buyPaymentMethod === 'bkash' ? 'বিকাশ' : 'নগদ'} পার্সোনাল নাম্বার (Send Money করুন):
                          </p>
                          <p className="text-lg font-black font-mono text-white tracking-widest">{CONTACT_PHONE}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText(CONTACT_PHONE, buyPaymentMethod === 'bkash' ? 'bKash' : 'Nagad')}
                          className="px-3.5 py-2 hover:bg-gray-800 border border-gray-700 rounded-lg text-xs font-bold text-blue-400 flex items-center gap-1.5 transition-colors"
                        >
                          <Copy className="w-3.5 h-3.5" /> কপি করুন
                        </button>
                      </motion.div>
                    )}

                    {/* Bank Transfer info and WhatsApp gateway */}
                    {buyPaymentMethod === 'bank' && (
                      <motion.div 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-3.5 bg-blue-900/10 border border-blue-500/20 p-4 rounded-xl space-y-3"
                      >
                        <p className="text-xs text-gray-300 leading-relaxed">
                          ব্যাংক পেমেন্টের (Brac Bank, City Bank, Islami Bank ইত্যাদি) যাবতীয় তথ্য পেতে সরাসরি হোয়াটসঅ্যাপে আমাদের সাথে কথা বলুন।
                        </p>
                        <a 
                          href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি ব্যাংক ট্রান্সফারের মাধ্যমে ৩.৫ মিনিটে USDT ডলার কিনতে চাই। অনুগ্রহ করে আপনার ব্যাংক একাউন্ট সংক্রান্ত তথ্য দিন।')}`}
                          target="_blank" 
                          rel="noreferrer"
                          className="inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-green-600 hover:bg-green-700 transition-colors text-xs font-black text-white"
                        >
                          <MessageSquare className="w-4 h-4" /> ব্যাংকে পেমেন্টের জন্য হোয়াটসঅ্যাপ ইনবক্স করুন
                        </a>
                      </motion.div>
                    )}
                  </div>

                  {/* Transaction verification ID with caller phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                        পেমেন্ট ট্রানজেকশন ID (TxID) <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={buyTxnId}
                        onChange={(e) => setBuyTxnId(e.target.value)}
                        placeholder="যেমন: Trx9XlM9p2K"
                        className="w-full h-11 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-xs font-mono text-white placeholder-gray-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                        পেমেন্ট পাঠানো ফোন নম্বর <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={buyPayerPhone}
                        onChange={(e) => setBuyPayerPhone(e.target.value)}
                        placeholder="যেমন: জমা দেওয়া বিকাশ নম্বরটি"
                        className="w-full h-11 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-xs text-white placeholder-gray-500"
                      />
                    </div>
                  </div>

                  {/* Attachment Zone */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5 uppercase tracking-wider">
                      পেমেন্টের প্রুফ স্ক্রিনশট <span className="text-red-500">*</span>
                    </label>
                    <p className="text-[11px] text-gray-400 mb-2.5">
                      টাকা পাঠানোর পর বিকাশ বা নগদের রিসিভ স্ক্রিনশটটি আপলোড দিন (ডেলিভারিতে সাহায্য করবে)
                    </p>
                    
                    <div 
                      onDragOver={handleDragOver}
                      onDrop={(e) => {
                        e.preventDefault();
                        const file = e.dataTransfer.files?.[0];
                        if (file) {
                          const mockInput = { files: e.dataTransfer.files } as any;
                          handleFileChange(mockInput, 'buy');
                        }
                      }}
                      className="border-2 border-dashed border-gray-800 hover:border-blue-500/40 bg-black/10 hover:bg-blue-950/5 transition-all rounded-2xl p-6 text-center cursor-pointer relative"
                    >
                      <input 
                        type="file" 
                        id="buy-screenshot-input" 
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={(e) => handleFileChange(e, 'buy')}
                      />
                      
                      {!buyPreview ? (
                        <div className="flex flex-col items-center">
                          <UploadCloud className="w-10 h-10 text-gray-500 mb-2" />
                          <span className="text-xs font-bold text-gray-300">ইমেজ ফাইলটি ক্লিক বা ড্র্যাগ এন্ড ড্রপ করে আনুন</span>
                          <span className="text-[10px] text-gray-500 mt-1">JPEG, PNG, WEBP (সর্বোচ্চ ৫ মেগাবাইট)</span>
                        </div>
                      ) : (
                        <div className="relative z-20">
                          <img 
                            src={buyPreview} 
                            alt="Screenshot preview" 
                            className="max-h-36 mx-auto rounded-lg object-contain border border-gray-700/60 mb-2"
                            referrerPolicy="no-referrer"
                          />
                          <p className="text-[11px] text-gray-400 truncate max-w-xs mx-auto">
                            {buyFile?.name}
                          </p>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              removeFile('buy');
                            }}
                            className="mt-2 inline-flex items-center gap-1 py-1 px-2.5 bg-red-900/50 hover:bg-red-900 border border-red-500/30 rounded-lg text-[10px] text-red-200 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> রিমুভ ইমেজ
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Submission elements for Tab 1 */}
                  <button
                    type="submit"
                    disabled={submittingBuy}
                    className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 transition-all text-white font-black text-sm rounded-xl flex items-center justify-center gap-2.5 shadow-lg shadow-blue-500/10 active:scale-[0.98] disabled:opacity-75"
                  >
                    {submittingBuy ? (
                      <>
                        <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        অর্ডার তথ্য যাচাই হচ্ছে...
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-5 h-5 text-green-300" /> Convert Buy — অর্ডার কনফার্ম করুন
                      </>
                    )}
                  </button>

                  <div className="flex justify-center items-center gap-5 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1 text-green-400 font-bold">
                      <ShieldCheck className="w-3.5 h-3.5" /> সম্পূর্ণ নিরাপদ
                    </span>
                    <span>•</span>
                    <span>অটোমেটিক ৩-৫ মিনিটে ইনস্ট্যান্ট ডেলিভারি</span>
                  </div>
                </motion.form>
              ) : (
                /* TAB-2: SELL CRYPTO FORM */
                <motion.form
                  key="sell-form"
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -15 }}
                  transition={{ duration: 0.25 }}
                  onSubmit={handleSellSubmit}
                  className="p-6 md:p-8 space-y-6"
                >
                  {/* Exchange Account details box (Where user sends their USDT first) */}
                  <div className="bg-blue-950/20 rounded-2xl p-4 border border-blue-500/15 space-y-3.5">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-blue-400 shrink-0" />
                      <span className="text-xs font-bold text-blue-300">আমাদের অফিশিয়াল Exchange UID-সমূহ:</span>
                    </div>
                    <p className="text-[11px] text-gray-400 leading-relaxed -mt-1.5">
                      নিচের যেকোনো একটি অ্যাকাউন্টে আপনার বাইনান্স বা বাইবিট হতে ডিরেক্ট ওয়ালেট ট্রান্সফার (Internal Transfer) করে USDT ডলার পাঠান।
                    </p>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div className="bg-black/30 border border-gray-800/80 rounded-xl p-3 flex items-center justify-between">
                        <div>
                          <span className="text-[9px] uppercase font-bold text-gray-400 block tracking-wider mb-0.5">Binance ID</span>
                          <span className="text-sm font-black font-mono text-white">1184375703</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText('1184375703', 'Binance ID')}
                          className="p-1 px-2 hover:bg-gray-800 rounded-lg text-blue-400 transition-colors text-[10px] font-bold inline-flex items-center gap-1 border border-gray-800"
                        >
                          <Copy className="w-3" /> কপি
                        </button>
                      </div>

                      <div className="bg-black/30 border border-gray-800/80 rounded-xl p-3 flex items-center justify-between">
                        <div>
                          <span className="text-[9px] uppercase font-bold text-gray-400 block tracking-wider mb-0.5">Bybit ID</span>
                          <span className="text-sm font-black font-mono text-white">527717624</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText('527717624', 'Bybit ID')}
                          className="p-1 px-2 hover:bg-gray-800 rounded-lg text-blue-400 transition-colors text-[10px] font-bold inline-flex items-center gap-1 border border-gray-800"
                        >
                          <Copy className="w-3" /> কপি
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Conversion display box */}
                  <div className="bg-[#0b0f19]/70 rounded-2xl p-4 border border-gray-800/80 space-y-2.5">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                      <span>কারেন্ট কনভার্সন রেট:</span>
                      <span className="font-bold font-mono text-blue-400">৳১২১.৭৯ BDT</span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-gray-400">
                      <span>USDT বিক্রয় পরিমাণ:</span>
                      <span className="font-bold text-white">
                        {sellAmount ? `${parseFloat(sellAmount).toFixed(2)} USDT` : '0.00 USDT'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-2.5 mt-1.5 border-t border-gray-800/50">
                      <span className="text-sm font-semibold text-gray-300">আপনি সর্বমোট নগদ পাবেন:</span>
                      <span className="text-lg font-black text-blue-400 font-mono">
                        ৳{sellAmount ? (parseFloat(sellAmount) * SYSTEM_USDT_RATE).toLocaleString('bn-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '০.০০'} BDT
                      </span>
                    </div>
                  </div>

                  {/* Customer UID for transaction reconciliation */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                      আপনার Binance / Bybit-এর UID <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={sellUid}
                      onChange={(e) => setSellUid(e.target.value)}
                      placeholder="যে একাউন্ট থেকে পাঠিয়েছেন সেটির UID লিখুন"
                      className="w-full h-12 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-sm text-white placeholder-gray-500"
                    />
                  </div>

                  {/* Amount to cash out */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                      কত ডলার বিক্রি করতে চান? (USDT) <span className="text-red-500">*</span>
                    </label>
                    <div className="relative mb-3">
                      <input
                        type="number"
                        min="1"
                        step="0.01"
                        required
                        value={sellAmount}
                        onChange={(e) => setSellAmount(e.target.value)}
                        placeholder="ডলারের পরিমান লিখুন"
                        className="w-full h-12 px-4 pr-16 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-sm font-semibold text-white placeholder-gray-500"
                      />
                      <div className="absolute right-3.5 top-2.5 bottom-2.5 px-3 bg-gray-800 rounded-lg text-xs font-bold text-blue-400 flex items-center border border-gray-700">
                        USDT
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {[10, 25, 50, 100, 200, 500].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setSellAmount(preset.toString())}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                            sellAmount === preset.toString()
                              ? 'bg-blue-600 border-blue-500 text-white'
                              : 'bg-[#0B0F19]/40 border-gray-800 text-gray-400 hover:text-white'
                          }`}
                        >
                          ${preset}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Payout Channel destination selection */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-3 uppercase tracking-wider">
                      টাকা গ্রহণের মাধ্যম <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-3 gap-2.5">
                      {/* bKash receive card */}
                      <div 
                        onClick={() => setSellPaymentMethod('bkash')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          sellPaymentMethod === 'bkash' ? 'border-pink-500 bg-pink-500/5 shadow-md shadow-pink-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-pink-500/10">
                          <span className="font-black text-xs text-pink-500">bKash</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">বিকাশ</span>
                      </div>
                      
                      {/* Nagad Receive card */}
                      <div 
                        onClick={() => setSellPaymentMethod('nagad')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          sellPaymentMethod === 'nagad' ? 'border-orange-500 bg-orange-500/5 shadow-md shadow-orange-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-orange-500/10">
                          <span className="font-black text-xs text-orange-500">নগদ</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">নগদ</span>
                      </div>

                      {/* Bank receive card */}
                      <div 
                        onClick={() => setSellPaymentMethod('bank')}
                        className={`p-3 rounded-xl border text-center cursor-pointer bg-black/20 hover:bg-gray-800/10 transition-all ${
                          sellPaymentMethod === 'bank' ? 'border-blue-500 bg-blue-500/5 shadow-md shadow-blue-500/5' : 'border-gray-800'
                        }`}
                      >
                        <div className="w-10 h-10 mx-auto mb-1.5 rounded-lg flex items-center justify-center bg-blue-500/10">
                          <span className="font-black text-xs text-blue-500">Bank</span>
                        </div>
                        <span className="text-xs font-medium text-gray-300">ব্যাংক ক্যাশ</span>
                      </div>
                    </div>

                    {/* Bank Transfer redirect note */}
                    {sellPaymentMethod === 'bank' && (
                      <motion.div 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-3.5 bg-blue-900/10 border border-blue-500/20 p-4 rounded-xl space-y-3"
                      >
                        <p className="text-xs text-gray-300 leading-relaxed">
                          ব্যাংক ক্যাশআউট ডিপোজিটের তথ্য এবং পেমেন্ট রিসিভ করতে সরাসরি কাস্টমার সাপোর্টের সাথে জয়েন করুন।
                        </p>
                        <a 
                          href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('আসসালামু আলাইকুম, আমি ব্যাংকে পেমেন্ট নিয়ে USDT ডলার সেল করতে আগ্রহী।')}`}
                          target="_blank" 
                          rel="noreferrer"
                          className="inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-green-600 hover:bg-green-700 transition-colors text-xs font-black text-white"
                        >
                          <MessageSquare className="w-4 h-4" /> ব্যাংক পেমেন্ট নিতে হোয়াটসঅ্যাপ করুন
                        </a>
                      </motion.div>
                    )}
                  </div>

                  {/* Customer Payout Phone target */}
                  {sellPaymentMethod && sellPaymentMethod !== 'bank' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="overflow-hidden"
                    >
                      <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                        আপনার {sellPaymentMethod === 'bkash' ? 'বিকাশ' : 'নগদ'} পার্সোনাল নাম্বার <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={sellReceiverPhone}
                        onChange={(e) => setSellReceiverPhone(e.target.value)}
                        placeholder="ভুল নাম্বার দিলে পেমেন্ট ব্যাহত হতে পারে"
                        className="w-full h-12 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-sm text-white placeholder-gray-500"
                      />
                    </motion.div>
                  )}

                  {/* Sent Crypto Txn ID */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-2 uppercase tracking-wider">
                      USDT Transfer Transaction ID / Hash <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={sellTxnId}
                      onChange={(e) => setSellTxnId(e.target.value)}
                      placeholder="ডলার পাঠানোর পর বাইনান্স/বাইবিট রিসিট হতে TxID লিখুন"
                      className="w-full h-11 px-4 bg-black/30 border border-gray-700/80 rounded-xl focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none transition-all text-xs font-mono text-white placeholder-gray-500"
                    />
                  </div>

                  {/* Attachment zone for sell verification proof */}
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1.5 uppercase tracking-wider">
                      ডলার পাঠানোর কনফার্মেশন স্ক্রিনশট <span className="text-red-500">*</span>
                    </label>
                    <p className="text-[11px] text-gray-400 mb-2.5">
                      ওয়ালেট ট্রান্সফার করার পর একটি screenshot তুলে দিন
                    </p>
                    
                    <div 
                      onDragOver={handleDragOver}
                      onDrop={(e) => {
                        e.preventDefault();
                        const file = e.dataTransfer.files?.[0];
                        if (file) {
                          const mockInput = { files: e.dataTransfer.files } as any;
                          handleFileChange(mockInput, 'sell');
                        }
                      }}
                      className="border-2 border-dashed border-gray-800 hover:border-blue-500/40 bg-black/10 hover:bg-blue-950/5 transition-all rounded-2xl p-6 text-center cursor-pointer relative"
                    >
                      <input 
                        type="file" 
                        id="sell-screenshot-input" 
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={(e) => handleFileChange(e, 'sell')}
                      />
                      
                      {!sellPreview ? (
                        <div className="flex flex-col items-center">
                          <UploadCloud className="w-10 h-10 text-gray-500 mb-2" />
                          <span className="text-xs font-bold text-gray-300">ক্লিক অথবা ড্র্যাগ এন্ড ড্রপ দিয়ে স্ক্রিনশট আনুন</span>
                          <span className="text-[10px] text-gray-500 mt-1">JPEG, PNG, WEBP (সর্বোচ্চ ৫ মেগাবাইট)</span>
                        </div>
                      ) : (
                        <div className="relative z-20">
                          <img 
                            src={sellPreview} 
                            alt="Screenshot preview" 
                            className="max-h-36 mx-auto rounded-lg object-contain border border-gray-700/60 mb-2"
                            referrerPolicy="no-referrer"
                          />
                          <p className="text-[11px] text-gray-400 truncate max-w-xs mx-auto">
                            {sellFile?.name}
                          </p>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              removeFile('sell');
                            }}
                            className="mt-2 inline-flex items-center gap-1 py-1 px-2.5 bg-red-900/50 hover:bg-red-900 border border-red-500/30 rounded-lg text-[10px] text-red-200 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> রিমুভ ইমেজ
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Submission and Trust element */}
                  <button
                    type="submit"
                    disabled={submittingSell}
                    className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 transition-all text-white font-black text-sm rounded-xl flex items-center justify-center gap-2.5 shadow-lg shadow-blue-500/10 active:scale-[0.98] disabled:opacity-75"
                  >
                    {submittingSell ? (
                      <>
                        <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        আপলোড হচ্ছে...
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-5 h-5 text-green-300" /> Convert Sell — অর্ডার কনফার্ম করুন
                      </>
                    )}
                  </button>

                  <div className="flex justify-center items-center gap-5 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1 text-green-400 font-bold">
                      <ShieldCheck className="w-3.5 h-3.5" /> ১০০% সুরিক্ষত
                    </span>
                    <span>•</span>
                    <span>লেনদেন সম্পন্ন হবার ৩-৫ মিনিটে টাকা বিকাশ/নগদে ডিপোজিট</span>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>

          </div>
        </div>
      </section>

      {/* ========== LIVE RECENT TRANSACTION TICKERS & customer review indicators ========== */}
      <section id="live-ticker" className="py-16 md:py-24 bg-[#121826]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-full px-4 py-1.5 mb-4">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse shrink-0" />
              <span className="text-[10px] sm:text-xs font-mono font-bold text-red-500 uppercase tracking-widest leading-none">LIVE UPDATES</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-3">
              সাম্প্রতিক লেনদেন ও কাস্টমার ফিডব্যাক
            </h2>
            <p className="text-gray-400 text-sm md:text-base max-w-xl mx-auto">
              আমাদের এক্সচেঞ্জ গেটওয়েতে রিয়েল-টাইমে সম্পন্ন হওয়া পেমেন্ট ও গ্রাহকদের মতামত সরাসরি দেখে নিন।
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            
            {/* Live Ticker panel */}
            <div className="glass-strong rounded-3xl overflow-hidden border border-gray-800 shadow-xl">
              <div className="flex items-center justify-between px-6 py-5 border-b border-gray-800 bg-[#0B0F19]/60">
                <div className="flex items-center gap-3">
                  <span className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                  </span>
                  <h3 className="font-bold text-base md:text-lg text-white">সর্বশেষ পেমেন্ট ট্র্যাকার</h3>
                </div>
                <div className="flex items-center gap-1.5 bg-red-500/15 border border-red-500/30 rounded-full px-3 py-1 text-[10px] font-black text-red-400 tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  LIVE
                </div>
              </div>

              <div className="divide-y divide-gray-800/50 max-h-[460px] overflow-y-auto">
                <AnimatePresence initial={false}>
                  {payments.map((p) => {
                    const isSell = p.method.includes('USDT →');
                    return (
                      <motion.div
                        key={p.id}
                        initial={{ opacity: 0, y: -20, height: 0 }}
                        animate={{ opacity: 1, y: 0, height: "auto" }}
                        exit={{ opacity: 0, y: 20, height: 0 }}
                        transition={{ duration: 0.35, cubicBezier: [0.16, 1, 0.3, 1] }}
                        className="flex items-center justify-between px-6 py-4 hover:bg-gray-800/20 transition-colors"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                            isSell 
                              ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' 
                              : 'bg-green-500/10 border-green-500/20 text-green-400'
                          }`}>
                            <span className="text-[10px] font-black">
                              {isSell ? 'SELL' : 'BUY'}
                            </span>
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs sm:text-sm font-semibold text-white truncate" title={p.method}>
                              {p.method}
                            </p>
                            <span className="text-[10px] sm:text-xs text-gray-400">
                              {p.time}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 shrink-0">
                          <span className="text-xs sm:text-sm font-black font-mono text-blue-400">
                            {p.amount}
                          </span>
                          <span className="px-2.5 py-1 rounded-full text-[9px] font-black bg-green-500/10 text-green-400 border border-green-500/20 whitespace-nowrap">
                            Completed
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>

            {/* Live Customer Feedbacks */}
            <div className="glass-strong rounded-3xl overflow-hidden border border-gray-800 shadow-xl">
              <div className="flex items-center justify-between px-6 py-5 border-b border-gray-800 bg-[#0B0F19]/60">
                <div className="flex items-center gap-3">
                  <span className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                    <Smile className="w-5 h-5 text-amber-400" />
                  </span>
                  <h3 className="font-bold text-base md:text-lg text-white">গ্রাহকদের ফিডব্যাক ও মতামত</h3>
                </div>
                <div className="flex items-center gap-1.5 bg-red-500/15 border border-red-500/30 rounded-full px-3 py-1 text-[10px] font-black text-red-400 tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  LIVE
                </div>
              </div>

              <div className="p-5 space-y-4 max-h-[460px] overflow-y-auto">
                <AnimatePresence initial={false}>
                  {reviews.map((r) => (
                    <motion.div
                      key={r.id}
                      initial={{ opacity: 0, scale: 0.95, y: 15 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: -15 }}
                      transition={{ duration: 0.35 }}
                      className="glass-card rounded-2xl p-4 border border-gray-800/80 hover:border-gray-700 transition-colors"
                    >
                      <div className="flex items-center gap-3 mb-2.5">
                        <div className={`w-9 h-9 rounded-full ${r.color} flex items-center justify-center font-bold text-xs uppercase ${r.tc} shrink-0`}>
                          {r.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs sm:text-sm font-semibold text-white truncate">{r.name}</p>
                          <span className="text-[10px] text-gray-500 font-medium block leading-none mt-1">{r.time}</span>
                        </div>
                        <div className="flex gap-0.5 shrink-0">
                          {[...Array(r.rating)].map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs sm:text-sm text-gray-300 leading-relaxed pl-1">
                        {r.text}
                      </p>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* ========== TRUST GRIDS — WHY CHOOSE COINSWAP? ========== */}
      <section id="why-choose-us" className="py-16 md:py-24 bg-[#0B0F19]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          
          <div className="text-center mb-16 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight mb-4">
              কেন আমরাই বাংলাদেশের ১ নম্বর গেটওয়ে?
            </h2>
            <p className="text-gray-400 text-sm md:text-base leading-relaxed">
              স্বচ্ছ ও আধুনিক ক্রিপ্টো লেনদেনের সব সুবিধা নিশ্চিত করে আমরা গত কয়েক বছর যাবৎ আস্থার সাথে গ্রাহক সেবা প্রদান করছি।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {/* Feature 1 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/gkYLrLQ5/file-00000000ca187208ae89ada5e18c24a1.png" 
                  alt="Trusted Exchange" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">শীর্ষস্থানীয় বিশ্বস্ত এক্সচেঞ্জ</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  হাজার হাজার সন্তুষ্ট গ্রাহকের ইতিবাচক মতামত ও নিরবচ্ছিন্ন সার্ভিস নিয়ে আমরা নির্ভরযোগ্য প্ল্যাটফর্ম। প্রতিটি অর্ডার সতর্কতার সাথে দ্রুত সম্পন্ন করা হয়।
                </p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/zXJH3H64/file-0000000029ac7208a3e4315bb6b33363.png" 
                  alt="Secure Transactions" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">১০০% সম্পূর্ণ সুরক্ষিত লেনদেন</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  আপনার পার্সোনাল ইনফরমেশন এবং ফান্ডের সিকিউরিটি আমাদের ফার্স্ট প্রায়োরিটি। অত্যাধুনিক পেমেন্ট সিকিউরিটি প্রোটোকলের মাধ্যমে প্রতিটি ট্রানজেকশন প্রসেস হয়।
                </p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/X7VBXBmP/file-00000000fd147208806eaf2af62501eb.png" 
                  alt="Instat Delivery" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <Zap className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">৩-৫ মিনিটে অতি দ্রুত অর্ডার ডেলিভারি</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  সবচেয়ে দ্রুত সময়ে পেমেন্ট ক্লিয়ারেন্স সুবিধা। অর্ডার ভেরিফাই হবার সাথে সাথে কয়েক মিনিটের মধ্যে আপনার বিকাশ, নগদ বা USDT ওয়ালেটে পেমেন্ট পৌঁছে যায়।
                </p>
              </div>
            </div>

            {/* Feature 4 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/028KrKhq/file-00000000d1fc7208bc6e9285d5de48a9.png" 
                  alt="Customer Support" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <Smile className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">শতভাগ গ্রাহক সন্তুষ্টি</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  আমাদের মূল লক্ষ্য গ্রাহকের মুখে হাসি এনে দেওয়া। স্বচ্ছ রেট, নির্ভুল পেমেন্ট মেকানিজম এবং প্রিমিয়াম কনভার্সন এক্সপেরিয়েন্স নিয়ে আমাদের ব্যবহারকারীরা সন্তুষ্ট।
                </p>
              </div>
            </div>

            {/* Feature 5 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/qMjhKMdd/file-00000000a5cc7208822c5c44cc70941b.png" 
                  alt="Best Exchange Rate" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">মার্কেটের সেরা এক্সচেঞ্জ রেট</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  সবচেয়ে প্রতিযোগিতামূলক বাই এবং সেল করার সুযোগ। মধ্যস্বত্বভোগী ছাড়াই সরাসরি মার্কেটের বেস্ট ডিল নিশ্চিত করে প্রিমিয়াম সার্ভিস উপভোগ করুন।
                </p>
              </div>
            </div>

            {/* Feature 6 */}
            <div className="bg-[#121826] rounded-2xl border border-gray-800/60 hover:border-blue-500/20 overflow-hidden group transition-all duration-300 hover:-translate-y-1.5 shadow-lg">
              <div className="aspect-video w-full overflow-hidden bg-gray-900 border-b border-gray-800">
                <img 
                  src="https://i.postimg.cc/RVX6tVxs/file-00000000d6107208817af0c76a257337.png" 
                  alt="24/7 Premium Support" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3.5 mb-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                    <Headphones className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-base text-white">২৪/৭ এক্টিভ কাস্টমার সাপোর্ট</h3>
                </div>
                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                  যেকোনো প্রয়োজনে বা তথ্যের জন্য আমাদের দক্ষ কাস্টমার সাপোর্ট এক্সপার্টরা সবসময় পাশে আছেন। হোয়াটসঅ্যাপ চ্যাট বা কলের রেসপন্স পাওয়া যায় দ্রুততম সময়ে।
                </p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* ========== STEP BY STEP GUIDE ========== */}
      <section className="py-16 md:py-24 bg-[#121826]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          <h2 className="text-3xl md:text-4xl font-extrabold text-center text-white mb-20 tracking-tight">
            কিভাবে CoinSwap-এ ট্রেড করবেন?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative max-w-4xl mx-auto">
            {/* Dashed absolute line separator */}
            <div className="hidden md:block absolute top-10 left-1/6 right-1/6 h-0.5 border-t border-dashed border-gray-800" />

            <div className="relative text-center">
              <div className="w-16 h-16 bg-blue-600/10 border-2 border-blue-500/30 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-500/5">
                <span className="font-display text-2xl font-black text-blue-500">১</span>
              </div>
              <h3 className="font-bold text-base text-white mb-2">পছন্দের মাধ্যম নির্বাচন</h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                ডলার বাই বা সেল ফর্ম অনুযায়ী বিকাশ, নগদ বা ব্যাংক ট্রান্সফার সিলেক্ট করে ডলারের পরিমাণ প্রদান করুন।
              </p>
            </div>

            <div className="relative text-center">
              <div className="w-16 h-16 bg-blue-600/10 border-2 border-blue-500/30 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-500/5">
                <span className="font-display text-2xl font-black text-blue-500">২</span>
              </div>
              <h3 className="font-bold text-base text-white mb-2">লেনদেন ও প্রমানাদি প্রদান</h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                পেমেন্ট সম্পন্ন করার পর ট্রানজেকশন ID ও স্ক্রিনশট দিয়ে সাবমিট বাটন ক্লিক করুন।
              </p>
            </div>

            <div className="relative text-center">
              <div className="w-16 h-16 bg-blue-600/10 border-2 border-blue-500/30 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-500/5">
                <span className="font-display text-2xl font-black text-blue-500">৩</span>
              </div>
              <h3 className="font-bold text-base text-white mb-2">তাত্ক্ষণিক পেমেন্ট রিসিভ</h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                হোয়াটসঅ্যাপে ডিরেক্ট রিডাইরেক্ট হয়ে মেসেজ দিন এবং ৩-৫ সেকেন্ড ভেরিফাই শেষে মিনিটে ফান্ড পেয়ে যান।
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========== COLLAPSIBLE FAQ MODULE ========== */}
      <section id="faq" className="py-16 md:py-24 bg-[#0B0F19]">
        <div className="max-w-[760px] mx-auto px-4 md:px-6">
          
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-3">
              সাধারণ জিজ্ঞাসা (FAQ)
            </h2>
            <p className="text-gray-400 text-xs sm:text-sm">
              আমাদের এক্সচেঞ্জ গেটওয়ে নিয়ে কিছু সাধারণ প্রশ্ন এবং সাহায্যকারী উত্তরসমূহ।
            </p>
          </div>

          <div className="space-y-4">
            {/* FAQ 1 */}
            <details className="group bg-[#121826] rounded-2xl border border-gray-800/80 overflow-hidden transition-colors duration-300">
              <summary className="flex justify-between items-center p-5 md:p-6 cursor-pointer list-none font-semibold text-sm text-white select-none">
                ১৮ পেমেন্ট পেতে কত সময় লাগবে?
                <ChevronDown className="w-4 h-4 text-gray-400 transition-transform group-open:rotate-180" />
              </summary>
              <div className="p-5 md:p-6 pt-0 border-t border-gray-800/60 text-xs sm:text-sm text-gray-400 leading-relaxed">
                সাধারণত ট্রানজেকশন সম্পন্ন করে সাবমিট করার পর আমাদের সাপোর্ট টিম থেকে ট্র্যাকিং নিশ্চিত হওয়া মাত্র ৩ থেকে ৫ মিনিটের ভেতরে ডেলিভারি করা হয়।
              </div>
            </details>

            {/* FAQ 2 */}
            <details className="group bg-[#121826] rounded-2xl border border-gray-800/80 overflow-hidden transition-colors duration-300">
              <summary className="flex justify-between items-center p-5 md:p-6 cursor-pointer list-none font-semibold text-sm text-white select-none">
                ২. এক্সচেঞ্জ এর কনভার্সন রেট পরিবর্তনশীল কি?
                <ChevronDown className="w-4 h-4 text-gray-400 transition-transform group-open:rotate-180" />
              </summary>
              <div className="p-5 md:p-6 pt-0 border-t border-gray-800/60 text-xs sm:text-sm text-gray-400 leading-relaxed">
                হ্যাঁ, গ্লোবাল ক্রিপ্টো এক্সচেঞ্জ পিয়্যার টু পিয়ার (P2P) মার্কেট রেট ও বৈশ্বিক ডলার কারেন্সির ওঠানামার ওপর ভিত্তি করে এক্সচেঞ্জ ভ্যালু সামান্য পরিবর্তন হতে পারে।
              </div>
            </details>

            {/* FAQ 3 */}
            <details className="group bg-[#121826] rounded-2xl border border-gray-800/80 overflow-hidden transition-colors duration-300">
              <summary className="flex justify-between items-center p-5 md:p-6 cursor-pointer list-none font-semibold text-sm text-white select-none">
                ৩. কোন কোন ক্রিপ্টোকারেন্সির লেনদেন সাপোর্ট করা হয়?
                <ChevronDown className="w-4 h-4 text-gray-400 transition-transform group-open:rotate-180" />
              </summary>
              <div className="p-5 md:p-6 pt-0 border-t border-gray-800/60 text-xs sm:text-sm text-gray-400 leading-relaxed">
                আমরা সরাসরি Binance, Bybit, OKX, KuCoin, Bitget, Coinbase, Quotex, RedotPay সহ প্রায় ২২টি মূলধারার ওয়ালেট মেথড এবং Tron TRC20 নেটওয়ার্কে ফুল সাপোর্ট দিয়ে থাকি।
              </div>
            </details>

            {/* FAQ 4 */}
            <details className="group bg-[#121826] rounded-2xl border border-gray-800/80 overflow-hidden transition-colors duration-300">
              <summary className="flex justify-between items-center p-5 md:p-6 cursor-pointer list-none font-semibold text-sm text-white select-none">
                ৪. ভুল ওয়ালেট অথবা ভুল নম্বর প্রদান করলে আমার কি করণীয়?
                <ChevronDown className="w-4 h-4 text-gray-400 transition-transform group-open:rotate-180" />
              </summary>
              <div className="p-5 md:p-6 pt-0 border-t border-gray-800/60 text-xs sm:text-sm text-gray-400 leading-relaxed">
                অবিলম্বে আপনার অর্ডারের স্ক্রিনশট ও ভুল সংশোধনের জন্য আমাদের হোয়াটসঅ্যাপ এজেন্টের সাথে সরাসরি যোগাযোগ করুন। ফান্ড ট্রান্সফার প্রক্রিয়া শুরু হবার আগে সেটি দ্রুত সংশোধন করতে আমাদের সাহায্য করবে।
              </div>
            </details>
          </div>

        </div>
      </section>

      {/* ========== MOBIL APP DOWNLOAD CONTAINER ========== */}
      <section id="download-app" className="py-16 md:py-24 bg-[#121826]">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">
                স্মার্টফোনেই ব্যবহার করুন CoinSwap অ্যাপ
              </h2>
              <p className="text-gray-400 text-sm leading-relaxed max-w-lg">
                যেকোনো সময়, যেকোনো স্থান থেকে আরো নিরাপদে এবং অত্যন্ত দ্রুততার সাথে ডলার কেনা-বেচার জন্য আমাদের অফিশিয়াল অ্যান্ড্রয়েড অ্যাপ ডাউনলোড দিন।
              </p>
              
              <div className="pt-2">
                <a 
                  href="https://play.google.com/store/apps/details?id=dev.vlab.com.local_coin" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3.5 px-8 py-4 bg-black border border-gray-800 rounded-2xl text-white hover:bg-gray-900 transition-all active:scale-[0.98] shadow-2xl shadow-black/50"
                >
                  {/* Google Play Store Vector Icon */}
                  <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.199l2.807 1.626a1 1 0 010 1.732l-2.807 1.626L15.206 12l2.492-2.492zM5.864 2.658L16.8 8.99l-2.302 2.302-8.634-8.634z"/>
                  </svg>
                  <div className="text-left leading-none">
                    <span className="text-[10px] text-gray-400 block tracking-wider uppercase mb-0.5">GET IT ON</span>
                    <span className="text-base font-bold text-white block">Google Play</span>
                  </div>
                </a>
              </div>
            </div>

            {/* Premium Mockup Graphics illustration */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative max-w-sm w-full">
                <div className="absolute inset-0 bg-blue-500/10 blur-3xl rounded-full" />
                <img 
                  src="https://i.postimg.cc/J0KNtNqt/file-0000000062e0720799c82bda09ee982f.png" 
                  alt="CoinSwap Pocket App" 
                  className="w-full h-auto rounded-3xl border border-gray-800/80 shadow-2xl relative z-10"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ========== FOOTER ========== */}
      <footer className="bg-[#0B0F19] border-t border-gray-800/80">
        <div className="max-w-[1240px] mx-auto px-4 md:px-12 py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 items-start">
          
          {/* Col 1: Branding and Satisfaction Rating */}
          <div className="space-y-5">
            <div className="flex items-center gap-3">
              <img 
                src="https://i.postimg.cc/cCGfLs83/IMG-20260524-WA0001.jpg" 
                alt="CoinSwap Logo" 
                className="h-10 w-10 rounded-full object-cover ring-2 ring-blue-500/20"
                referrerPolicy="no-referrer"
              />
              <span className="font-display text-xl font-extrabold text-white tracking-tight">
                Coin<span className="text-blue-500">Swap</span>
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-gray-450 text-gray-400 leading-relaxed">
              বাংলাদেশের অন্যতম শীর্ষ ও নির্ভরযোগ্য ক্রিপ্টোকারেন্সি গেটওয়ে। সহজে, নিরাপদে এবং দ্রুততম সময়ে বাই-সেল করুন।
            </p>

            <div className="pt-2">
              <div className="flex items-center gap-1 mb-1.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                ))}
                <span className="text-xs font-bold text-white ml-1.5">৪.৮ / ৫</span>
              </div>
              <p className="text-[11px] text-gray-400">১০,০০০ এর বেশি সন্তুষ্ট কাস্টমার ট্রাস্ট ফিডব্যাক</p>
            </div>
          </div>

          {/* Col 2: Navigation link structures */}
          <div>
            <h4 className="font-bold text-sm text-white mb-5 uppercase tracking-wider">রিসোর্স ও সেবা</h4>
            <ul className="space-y-3 text-xs sm:text-sm">
              <li>
                <button 
                  onClick={() => { setActiveTab('buy'); scrollToSection('form-section'); }}
                  className="text-gray-400 hover:text-blue-400 transition-colors cursor-pointer text-left"
                >
                  ডলার ক্রয় করুন (Buy USDT)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('sell'); scrollToSection('form-section'); }}
                  className="text-gray-400 hover:text-blue-400 transition-colors cursor-pointer text-left"
                >
                  ডলার বিক্রয় করুন (Sell USDT)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('wallet-rates')}
                  className="text-gray-400 hover:text-blue-400 transition-colors cursor-pointer text-left"
                >
                  ওয়ালেট ও গেটওয়ে রেট
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('faq')}
                  className="text-gray-400 hover:text-blue-400 transition-colors cursor-pointer text-left"
                >
                  সাহায্য এবং সাধারণ জিজ্ঞাসা (FAQ)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Payment gateway logos mockup */}
          <div>
            <h4 className="font-bold text-sm text-white mb-5 uppercase tracking-wider">পেমেন্ট পার্টনার</h4>
            
            <div className="grid grid-cols-3 gap-2 mb-6">
              <div className="h-9 bg-[#121826] border border-gray-800 rounded-lg flex items-center justify-center text-[10px] uppercase font-black text-pink-500 font-mono tracking-tight">bKash</div>
              <div className="h-9 bg-[#121826] border border-gray-800 rounded-lg flex items-center justify-center text-[10px] uppercase font-black text-orange-500 font-mono tracking-tight">Nagad</div>
              <div className="h-9 bg-[#121826] border border-gray-800 rounded-lg flex items-center justify-center text-[10px] uppercase font-bold text-blue-400 font-mono tracking-tight">Bank</div>
            </div>

            <a 
              href="https://play.google.com/store/apps/details?id=dev.vlab.com.local_coin"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-11 items-center justify-center gap-2 bg-black border border-gray-800 rounded-lg hover:bg-gray-900 transition-colors w-full"
            >
              <Download className="w-4 h-4 text-white" />
              <span className="text-xs font-bold text-white">গুগল প্লে স্টোর অ্যাপ</span>
            </a>
          </div>

          {/* Col 4: Contacts detail logic */}
          <div className="space-y-4">
            <h4 className="font-bold text-sm text-white mb-5 uppercase tracking-wider">যোগাযোগ করুন</h4>
            
            <ul className="space-y-3.5 text-xs sm:text-sm text-gray-400">
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <span>{CONTACT_PHONE}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <MessageSquare className="w-4 h-4 text-blue-400 shrink-0" />
                <a 
                  href={`https://wa.me/${WHATSAPP_NUMBER}`} 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-blue-400 transition-colors"
                >
                  {WHATSAPP_NUMBER} (হোয়াটসঅ্যাপ চ্যাট)
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <ExternalLink className="w-4 h-4 text-blue-400 shrink-0" />
                <a 
                  href="https://www.facebook.com/CoinSwap" 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-blue-400 transition-colors"
                >
                  Facebook অফিসিয়াল পেজ
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-gray-800/60 py-8 text-center bg-[#080B12]">
          <p className="text-xs text-gray-500 font-medium">
            © ২০২৫-২০২৬ CoinSwap. সকল অধিকার সংরক্ষিত।
          </p>
        </div>
      </footer>

      {/* Floating Premium WhatsApp Action */}
      <a 
        href={`https://wa.me/${WHATSAPP_NUMBER}`} 
        target="_blank" 
        rel="noreferrer"
        className="fixed bottom-6 right-6 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-xl shadow-[#25D366]/30 hover:scale-110 active:scale-95 transition-transform z-[200] group"
        aria-label="Contact support on WhatsApp"
      >
        {/* Interactive hover notification banner */}
        <div className="absolute right-full mr-3.5 bg-[#121826] border border-gray-800 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none tracking-wide">
          হেল্প প্রয়োজন? চ্যাট করুন 💬
        </div>

        <svg fill="currentColor" height="28" viewBox="0 0 24 24" width="28">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.937 3.658 1.43 5.63 1.434h.008c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>

    </div>
  );
}
